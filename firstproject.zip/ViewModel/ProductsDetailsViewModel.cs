﻿namespace EcommerceApi.api.ViewModel
{
    public class ProductsDetailsViewModel
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
