﻿using Microsoft.AspNetCore.Identity;

namespace EcommerceApi.api.Models.identity
{
    public class ApplicationUser:IdentityUser
    {

    }
}
